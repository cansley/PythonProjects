from distutils.core import setup

setup(
    name='HeadFirstPython',
    version='.09',
    packages=['Ch1'],
    url='http://www.google.com',
    license='',
    author='Charles Ansley',
    author_email='cansley2@gmail.com',
    description='Some dumb stuff. DO NOT USE!'
)
